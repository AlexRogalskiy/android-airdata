[Check the code of conduct here](/CODE_OF_CONDUCT.md)
## Best way of contribution is to find some open issue or bug and fix it!
[General contribution and contact info](http://www.basicairdata.eu/join/)
